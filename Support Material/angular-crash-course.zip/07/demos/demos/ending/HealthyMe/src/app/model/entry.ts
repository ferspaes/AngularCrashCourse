export class Entry {
  id: number;
  date: Date;
  weight: number;
  bodyfat: number;
}